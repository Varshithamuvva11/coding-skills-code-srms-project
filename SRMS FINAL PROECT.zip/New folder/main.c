#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STUDENT_FILE "students.txt"
#define CREDENTIAL_FILE "credentials.txt"

struct student {
    int roll;
    char name[50];
    float marks;
};

char currentRole[10];
char currentUser[50];

int loginSystem();
void createDefaultCredentials();
void mainMenu();
void adminMenu();
void userMenu();
void staffMenu();
void guestMenu();
void addStudent();
void displayStudents();
void searchStudent();
void updateStudent();
void deleteStudent();

int main() {
    createDefaultCredentials();
    if (loginSystem()) {
        mainMenu();
    } else {
        printf("\nAccess Denied. Exiting...\n");
    }
    return 0;
}

void createDefaultCredentials() {
    FILE *fp = fopen(CREDENTIAL_FILE, "r");
    if (!fp) {
        fp = fopen(CREDENTIAL_FILE, "w");
        if (fp) {
            fprintf(fp, "admin admin123 ADMIN\n");
            fprintf(fp, "user1 user123 USER\n");
            fclose(fp);
        }
    } else {
        fclose(fp);
    }
}

int loginSystem() {
    char username[50], password[50];
    
    printf("Username: ");
    fgets(username, 50, stdin);
    username[strcspn(username, "\n")] = 0;
    
    printf("Password: ");
    fgets(password, 50, stdin);
    password[strcspn(password, "\n")] = 0;

    FILE *fp = fopen(CREDENTIAL_FILE, "r");
    if (!fp) return 0;

    char line[200];
    char fileUser[50], filePass[50], fileRole[10];
    
    while (fgets(line, sizeof(line), fp)) {
        if (sscanf(line, "%s %s %s", fileUser, filePass, fileRole) == 3) {
            if (strcmp(username, fileUser) == 0 && strcmp(password, filePass) == 0) {
                strcpy(currentRole, fileRole);
                strcpy(currentUser, fileUser);
                fclose(fp);
                return 1;
            }
        }
    }
    fclose(fp);
    return 0;
}

void mainMenu() {
    if (strcmp(currentRole, "ADMIN") == 0) adminMenu();
    else if (strcmp(currentRole, "USER") == 0) userMenu();
    else if (strcmp(currentRole, "STAFF") == 0) staffMenu();
    else guestMenu();
}

void adminMenu() {
    int choice;
    while (1) {
        printf("\n=== ADMIN MENU ===\n");
        printf("1. Add Student\n");
        printf("2. Display Students\n");
        printf("3. Search Student\n");
        printf("4. Update Student\n");
        printf("5. Delete Student\n");
        printf("6. Logout\n");
        printf("Choice: ");
        scanf("%d", &choice); getchar();
        
        switch (choice) {
            case 1: addStudent(); break;
            case 2: displayStudents(); break;
            case 3: searchStudent(); break;
            case 4: updateStudent(); break;
            case 5: deleteStudent(); break;
            case 6: return;
        }
    }
}

void userMenu() {
    int choice;
    while (1) {
        printf("\n=== USER MENU ===\n");
        printf("1. Display Students\n");
        printf("2. Search Student\n");
        printf("3. Logout\n");
        printf("Choice: ");
        scanf("%d", &choice); getchar();
        switch (choice) {
            case 1: displayStudents(); break;
            case 2: searchStudent(); break;
            case 3: return;
        }
    }
}

void staffMenu() { userMenu(); }
void guestMenu() { displayStudents(); }

void addStudent() {
    struct student s;
    printf("Roll: "); scanf("%d", &s.roll); getchar();
    
    FILE *check = fopen(STUDENT_FILE, "r");
    struct student temp;
    if (check) {
        while (fscanf(check, "%d %s %f", &temp.roll, temp.name, &temp.marks) == 3) {
            if (temp.roll == s.roll) {
                printf("Roll exists!\n");
                fclose(check);
                return;
            }
        }
        fclose(check);
    }
    
    printf("Name: ");
    fgets(s.name, 50, stdin);
    s.name[strcspn(s.name, "\n")] = 0;
    printf("Marks: "); scanf("%f", &s.marks);
    
    FILE *fp = fopen(STUDENT_FILE, "a");
    fprintf(fp, "%d %s %.2f\n", s.roll, s.name, s.marks);
    fclose(fp);
    printf("Added!\n");
}

void displayStudents() {
    struct student s;
    FILE *fp = fopen(STUDENT_FILE, "r");
    if (!fp) {
        printf("No students.\n");
        return;
    }
    printf("\nRoll     Name                       Marks\n");
    printf("----     -------------------------  -----\n");
    while (fscanf(fp, "%d %s %f", &s.roll, s.name, &s.marks) == 3) {
        printf("%-8d %-25s %.2f\n", s.roll, s.name, s.marks);
    }
    fclose(fp);
}

void searchStudent() {
    int roll;
    printf("Roll: "); scanf("%d", &roll);
    
    struct student s;
    FILE *fp = fopen(STUDENT_FILE, "r");
    if (!fp) return;
    
    while (fscanf(fp, "%d %s %f", &s.roll, s.name, &s.marks) == 3) {
        if (s.roll == roll) {
            printf("Roll: %d, Name: %s, Marks: %.2f\n", s.roll, s.name, s.marks);
            fclose(fp);
            return;
        }
    }
    printf("Not found!\n");
    fclose(fp);
}

void updateStudent() {
    int roll;
    printf("Roll: "); scanf("%d", &roll); getchar();
    
    struct student s;
    FILE *fp = fopen(STUDENT_FILE, "r");
    FILE *temp = fopen("temp.txt", "w");
    
    int found = 0;
    while (fscanf(fp, "%d %s %f", &s.roll, s.name, &s.marks) == 3) {
        if (s.roll == roll) {
            printf("New name: ");
            fgets(s.name, 50, stdin);
            s.name[strcspn(s.name, "\n")] = 0;
            printf("New marks: "); scanf("%f", &s.marks);
            found = 1;
        }
        fprintf(temp, "%d %s %.2f\n", s.roll, s.name, s.marks);
    }
    
    fclose(fp); fclose(temp);
    if (found) {
        remove(STUDENT_FILE);
        rename("temp.txt", STUDENT_FILE);
        printf("Updated!\n");
    } else {
        remove("temp.txt");
        printf("Not found!\n");
    }
}

void deleteStudent() {
    int roll;
    printf("Roll: "); scanf("%d", &roll);
    
    struct student s;
    FILE *fp = fopen(STUDENT_FILE, "r");
    FILE *temp = fopen("temp.txt", "w");
    
    int found = 0;
    while (fscanf(fp, "%d %s %f", &s.roll, s.name, &s.marks) == 3) {
        if (s.roll != roll) {
            fprintf(temp, "%d %s %.2f\n", s.roll, s.name, s.marks);
        } else {
            found = 1;
        }
    }
    
    fclose(fp); fclose(temp);
    if (found) {
        remove(STUDENT_FILE);
        rename("temp.txt", STUDENT_FILE);
        printf("Deleted!\n");
    } else {
        remove("temp.txt");
        printf("Not found!\n");
    }
}
